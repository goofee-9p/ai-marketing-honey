// 연속 붙여넣기 — 노션 검색창 구조(REA로 확인: 숨겨 둔 패널 창 · 전역 단축키)를 참고해 새로 짠 마케터용 툴
// Ctrl+Alt+V (맥: Control+Option+V): 지금 클립보드의 목록으로 연속 붙여넣기 시작/끝
// Ctrl+V (맥: ⌘V): 모드 켜진 동안 누를 때마다 다음 줄을 붙여넣음 (맥은 '손쉬운 사용' 권한 필요)
const { app, BrowserWindow, globalShortcut, clipboard, screen, systemPreferences } = require('electron');
const { execFile } = require('child_process');
const path = require('path');

const TOGGLE = process.platform === 'darwin' ? 'Control+Alt+V' : 'Control+Alt+V';   // 창업자 2026-10-18 확정
const PASTE = 'CommandOrControl+V';

let panel, queue = [], idx = 0, saved = '', on = false;

// 노션 글머리표·번호, 엑셀 칸(탭)까지 정리해 한 줄 = 한 개로
function parse(text) {
  return text.split(/\r?\n/).flatMap(l => l.split('\t'))
    .map(s => s.replace(/^\s*([-•*·▪︎]|\d+[.)])\s+/, '').trim())
    .filter(Boolean);
}

function createPanel() {
  const { workArea } = screen.getPrimaryDisplay();
  panel = new BrowserWindow({
    width: 360, height: 240, x: workArea.x + workArea.width - 380, y: workArea.y + 20,
    show: false, frame: false, type: 'panel', alwaysOnTop: true, focusable: false,
    resizable: false, hiddenInMissionControl: true, transparent: true, hasShadow: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js') },
  });
  panel.loadFile('panel.html');
  panel.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
}

function render() {
  panel.webContents.send('state', { on, idx, total: queue.length, items: queue });
}

function sendPaste() {
  if (process.platform === 'win32')   // 윈도우: Ctrl+V 보내기
    return new Promise(res => execFile('powershell', ['-NoProfile', '-Command', "(New-Object -ComObject WScript.Shell).SendKeys('^v')"], err => res(err)));
  return new Promise(res => execFile('osascript', ['-e', 'tell application "System Events" to key code 9 using command down'], (err, so, se) => { if (se) console.log('[osascript]', se.trim()); res(err); }));
}

async function pasteNext() {
  if (!on) return;
  if (idx >= queue.length) return stop();
  clipboard.writeText(queue[idx]);
  globalShortcut.unregister(PASTE);                 // 우리가 누르는 ⌘V가 다시 잡히지 않게 잠깐 해제
  const err = await sendPaste();
  if (err) console.log('[queue] 붙여넣기 실패 — 손쉬운 사용 권한을 확인하세요:', err.message);
  idx += 1; render();
  setTimeout(() => { if (on && idx < queue.length) globalShortcut.register(PASTE, pasteNext); else if (on) stop(); }, 120);
}

function start() {
  saved = clipboard.readText();
  queue = parse(saved); idx = 0;
  if (queue.length < 2) { console.log('[queue] 목록이 두 줄 이상이어야 해요'); return; }
  on = true;
  globalShortcut.register(PASTE, pasteNext);
  panel.showInactive(); render();                   // 포커스를 뺏지 않고 구석에 표시
  console.log(`[queue] 시작: ${queue.length}개`);
}

function stop() {
  on = false; globalShortcut.unregister(PASTE);
  clipboard.writeText(saved);                       // 원래 클립보드로 되돌림
  render(); setTimeout(() => panel.hide(), 1200);
  console.log('[queue] 끝');
}

app.whenReady().then(async () => {
  if (process.platform === 'darwin') app.dock.hide();
  // 붙여넣기 키를 대신 누르려면 '손쉬운 사용' 권한 필요 — 없으면 맥이 설정 창을 띄워 줌
  const trusted = systemPreferences.isTrustedAccessibilityClient(true);
  console.log('[queue] 손쉬운 사용 권한:', trusted ? '있음' : '없음 → 시스템 설정에서 켜 주세요');
  createPanel();
  globalShortcut.register(TOGGLE, () => (on ? stop() : start()));
  console.log(`[queue] ${TOGGLE} 로 시작/끝`);


});

app.on('will-quit', () => globalShortcut.unregisterAll());
