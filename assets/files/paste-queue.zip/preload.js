const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('queue', { onState: fn => ipcRenderer.on('state', (_e, s) => fn(s)) });
